let getplanmeal = document.getElementById("planMeal");
getplanmeal.addEventListener("click", ()=>{
    document.location.href = "../html/page3Type3.html";
})